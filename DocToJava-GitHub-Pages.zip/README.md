# DocToJava — GitHub Pages Edition

This version keeps the existing DocToJava UI and Java-generation prompts, but moves Gemini requests from the Express server into the browser so the app can run as a static GitHub Pages site.

## Important security note

Do **not** put a Gemini API key into GitHub source code or `VITE_GEMINI_API_KEY`.

Use the **Gemini Key** button inside the app. The key is stored in your browser's local storage and is sent directly to Google's Gemini API from the browser. Anyone who has access to the browser profile can use/remove that saved key.

Because the key is client-side, this is suitable for a personal/demo GitHub Pages deployment, not a production multi-user service. Gemini API quotas still apply; the website cannot provide literally unlimited API usage.

## Deploy on GitHub Pages

1. Create a GitHub repository.
2. Upload/extract all files from this project into the repository root.
3. Commit and push to the `main` branch.
4. Open **Settings → Pages** in the repository.
5. Under **Build and deployment**, choose **GitHub Actions**.
6. The workflow `.github/workflows/deploy.yml` will build and publish `dist/`.
7. After the workflow finishes, GitHub will show the Pages URL.

It will normally look like:

`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`

## Local development

```bash
npm install
npm run dev
```

Then open the local URL shown by Vite.

## Supported input

PDF, DOCX/DOC, text/Markdown, Java/code text, and images are retained from the original app. PDF/image files are sent to Gemini as inline content; DOCX text is extracted in the browser.

## What changed

- The original Express API endpoints are no longer required for GitHub Pages.
- `src/geminiClient.ts` contains the browser-side equivalents of generate, refine, and verify operations.
- The existing UI, Java generation rules, JSON structure, history, downloads, and refinement workflow are preserved.
- `vite.config.ts` uses a relative base so the app works at a GitHub Pages repository path.
