export interface SampleSpec {
  id: string;
  title: string;
  category: string;
  fileName: string;
  description: string;
  text: string;
  recommendedProjectType: "standard" | "spring-boot" | "junit" | "data-structures";
}

export const SAMPLE_SPECS: SampleSpec[] = [
  {
    id: "lru-cache-multithreaded",
    title: "Thread-Safe LRU Cache with TTL & Metrics",
    category: "Concurrency & Data Structures",
    fileName: "Assignment_3_LRU_Cache_Spec.pdf",
    description: "Design an in-memory, high-throughput, thread-safe LRU cache with time-to-live eviction and statistical hit-rate metrics.",
    recommendedProjectType: "data-structures",
    text: `# Problem Specification: Production-Grade Thread-Safe LRU Cache

## Requirements
1. Design a Generic LRU Cache (\`LRUCache<K, V>\`) supporting capacity limits and optional per-entry Time-To-Live (TTL).
2. Concurrency: Must support high-frequency simultaneous reads and writes from multiple threads without race conditions or deadlocks (prefer ReadWriteLock or StampedLock / concurrent segments).
3. Core Operations:
   - \`V get(K key)\`: retrieves value if present and not expired; updates eviction order.
   - \`void put(K key, V value)\`: inserts or updates. If capacity exceeded, evicts the least recently used non-expired entry.
   - \`void put(K key, V value, Duration ttl)\`: inserts with custom expiry.
   - \`boolean remove(K key)\`: explicitly removes an entry.
   - \`int size()\`: returns non-expired active size.
   - \`CacheStats getStats()\`: returns total hits, misses, evictions, and current hit ratio.
4. Clean architecture with custom double-linked list or LinkedHashMap encapsulation.
5. Provide comprehensive JUnit 5 unit tests verifying multithreaded concurrent puts/gets, TTL expiration, and LRU eviction order.`
  },
  {
    id: "ecommerce-order-engine",
    title: "E-Commerce Order Processing & Discount Engine",
    category: "Spring Boot / Enterprise",
    fileName: "Order_Service_Architecture_Spec.docx",
    description: "Multi-tiered domain model with Strategy pattern for discount calculations, stock validation, and idempotency.",
    recommendedProjectType: "spring-boot",
    text: `# Technical Specification: E-Commerce Order & Discount Engine

## Overview
Build an enterprise-grade Order Processing Service for an online retail platform.

## Functional Specs:
1. Domain Entities:
   - \`Customer\` (id, name, email, loyaltyTier: BRONZE, SILVER, GOLD, PLATINUM)
   - \`Product\` (sku, title, priceInCents, availableStock)
   - \`OrderItem\` (product, quantity, lineTotal)
   - \`Order\` (id, orderNumber, customer, items, discountApplied, totalAmount, status: CREATED, PAID, SHIPPED, CANCELLED)
2. Pricing & Discount Pipeline (Strategy Pattern):
   - Tiered Loyalty Discount (Bronze: 0%, Silver: 5%, Gold: 10%, Platinum: 20%)
   - Bulk Quantity Discount: If any single item >= 5 units, 8% off that line item.
   - Coupon Discount: Validates promotional coupon codes (e.g. "SUMMER25" -> $25 off orders > $100).
3. Order Service Operations:
   - \`Order createOrder(CreateOrderRequest request)\`: Validates stock, calculates prices with strategy chain, deducts stock atomically, and emits order events.
   - \`void cancelOrder(UUID orderId)\`: Restores inventory, transitions state cleanly.
4. Include validation, custom checked exceptions (\`InsufficientStockException\`, \`InvalidCouponException\`), and full JUnit test suite.`
  },
  {
    id: "expression-parser-ast",
    title: "Mathematical Expression Evaluator & AST Compiler",
    category: "Algorithms & Compilers",
    fileName: "Math_AST_Compiler_Assignment.pdf",
    description: "Lexer, Recursive-Descent Parser, and AST visitor for mathematical formulas with variables and functions.",
    recommendedProjectType: "standard",
    text: `# University CS Assignment: Mathematical Expression Parser & AST Evaluator

## Objective
Implement a robust arithmetic expression tokenizer and recursive descent AST parser in Java.

## Grammar Support:
- Numbers (integers, floating point: e.g., 3.1415, -42)
- Operators with precedence: \`+\`, \`-\`, \`*\`, \`/\`, \`^\` (exponentiation, right-associative)
- Parentheses: \`(\`, \`)\`
- Mathematical Functions: \`sin(x)\`, \`cos(x)\`, \`sqrt(x)\`, \`max(a, b)\`
- Dynamic Variable Bindings: e.g. \`x + 2 * y\`, evaluated with a \`Map<String, Double> context\`.

## Architectural Guidelines:
1. Tokenizer (Lexer) -> produces stream of typed tokens.
2. Parser -> builds an immutable Abstract Syntax Tree (\`ExpressionNode\` sealed interface with \`NumberNode\`, \`BinaryOpNode\`, \`FunctionNode\`, \`VariableNode\`).
3. Visitor Pattern:
   - \`EvaluationVisitor\`: calculates numerical result.
   - \`PrettyPrintVisitor\`: formats canonical expression string.
4. Error Handling: Syntax error reporting with exact column indices.
5. Runnable demo and unit tests.`
  },
  {
    id: "financial-transaction-ledger",
    title: "Double-Entry Bookkeeping & Audit Ledger",
    category: "FinTech & Banking",
    fileName: "Banking_Ledger_Specification.pdf",
    description: "Immutable double-entry financial ledger enforcing ACID accounting rules, currency safety, and audit hashing.",
    recommendedProjectType: "junit",
    text: `# Banking Systems Specification: Immutable Double-Entry Ledger

## Core Requirements:
1. Double-Entry Accounting Rule: Every financial transaction must consist of balanced Debits and Credits (\`sum(debits) == sum(credits)\`).
2. Currency Handling: Never use floating-point numbers for money! Use \`java.math.BigDecimal\` or custom monetary records with 4 decimal precision and rounding modes.
3. Cryptographic Audit Trail: Each posted transaction creates an immutable block containing the SHA-256 hash of (previousHash + transactionPayload + timestamp).
4. Entities:
   - \`Account\` (accountNumber, accountType: ASSET, LIABILITY, EQUITY, REVENUE, EXPENSE, currency)
   - \`JournalEntry\` (id, timestamp, description, List<PostingLine>)
   - \`PostingLine\` (account, entryType: DEBIT/CREDIT, amount)
   - \`AuditBlock\` (index, timestamp, previousHash, entryHash)
5. Methods:
   - \`void postTransaction(JournalEntry entry)\` throws \`UnbalancedJournalException\`, \`InvalidAccountStateException\`.
   - \`BigDecimal getAccountBalance(String accountNumber)\`.
   - \`boolean verifyLedgerIntegrity()\`: walks audit chain to verify no historical records were tampered with.`
  }
];
