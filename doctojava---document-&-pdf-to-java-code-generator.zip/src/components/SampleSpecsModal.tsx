import React from "react";
import { X, BookOpen, Sparkles, ArrowRight, FileText, CheckCircle2 } from "lucide-react";
import { SAMPLE_SPECS, SampleSpec } from "../data/samples";

interface SampleSpecsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSample: (sample: SampleSpec) => void;
}

export const SampleSpecsModal: React.FC<SampleSpecsModalProps> = ({
  isOpen,
  onClose,
  onSelectSample,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[85vh] overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Sample Document Specifications
              </h3>
              <p className="text-xs text-slate-400">
                Pick a real-world document spec to test instant conversion into clean Java
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* List of samples */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SAMPLE_SPECS.map((spec) => (
              <div
                key={spec.id}
                className="bg-slate-950 border border-slate-800 hover:border-amber-500/50 rounded-xl p-4 transition-all flex flex-col justify-between group cursor-pointer hover:shadow-lg hover:shadow-amber-500/5"
                onClick={() => {
                  onSelectSample(spec);
                  onClose();
                }}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                      {spec.category}
                    </span>
                    <span className="text-[11px] font-mono text-amber-400/90">
                      {spec.fileName}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors mb-1.5">
                    {spec.title}
                  </h4>
                  <p className="text-xs text-slate-400 line-clamp-3 mb-3">
                    {spec.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-900 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500 font-mono">
                    Mode: {spec.recommendedProjectType}
                  </span>
                  <button
                    type="button"
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-400 group-hover:text-amber-300 group-hover:translate-x-0.5 transition-transform"
                  >
                    <span>Load Spec</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-950 px-6 py-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>You can also upload any PDF, Word doc, or custom text anytime.</span>
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
