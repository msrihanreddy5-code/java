import React, { useState, useRef } from "react";
import {
  UploadCloud,
  FileText,
  FileCheck,
  Settings2,
  Trash2,
  Sparkles,
  Sliders,
  ChevronDown,
  ChevronUp,
  Code2,
  Cpu,
  Layers,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import { ProjectOptions } from "../types";

interface UploadZoneProps {
  onGenerate: (data: {
    fileData?: string;
    mimeType?: string;
    fileName?: string;
    extractedText?: string;
    options: ProjectOptions;
  }) => void;
  isLoading: boolean;
  onSelectSample: () => void;
}

export const UploadZone: React.FC<UploadZoneProps> = ({
  onGenerate,
  isLoading,
  onSelectSample,
}) => {
  const [activeTab, setActiveTab] = useState<"file" | "text">("file");
  const [selectedFile, setSelectedFile] = useState<{
    file: File;
    base64: string;
  } | null>(null);
  const [pastedText, setPastedText] = useState("");
  const [isDragging, setIsDragging] = useState(false);
  const [showConfig, setShowConfig] = useState(false);

  // Generation options
  const [options, setOptions] = useState<ProjectOptions>({
    javaVersion: "21",
    projectType: "standard",
    buildTool: "single-file",
    targetPackage: "com.solution",
    optimizationGoal: "clean-code",
    additionalInstructions: "",
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Extract pure base64 without data:... prefix
      const base64 = result.includes(",") ? result.split(",")[1] : result;
      setSelectedFile({ file, base64 });
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;

    if (activeTab === "file" && selectedFile) {
      onGenerate({
        fileData: selectedFile.base64,
        mimeType: selectedFile.file.type || "application/pdf",
        fileName: selectedFile.file.name,
        options,
      });
    } else if (activeTab === "text" && pastedText.trim()) {
      onGenerate({
        extractedText: pastedText.trim(),
        fileName: "pasted_spec.txt",
        options,
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  };

  const isFormValid =
    (activeTab === "file" && selectedFile !== null) ||
    (activeTab === "text" && pastedText.trim().length > 10);

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-2xl relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Mode selection tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-5 pb-4 border-b border-slate-800/80">
        <div className="flex items-center gap-1.5 p-1 bg-slate-950/70 border border-slate-800 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveTab("file")}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === "file"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <UploadCloud className="w-3.5 h-3.5" />
            <span>Upload Document / PDF</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("text")}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === "text"
                ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Paste Specification Text</span>
          </button>
        </div>

        <button
          type="button"
          onClick={onSelectSample}
          className="text-xs font-medium text-amber-400 hover:text-amber-300 underline underline-offset-4 decoration-amber-400/40 hover:decoration-amber-400 flex items-center gap-1 cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Need a sample spec to test?</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* File upload tab */}
        {activeTab === "file" && (
          <div>
            {!selectedFile ? (
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-8 sm:p-10 text-center cursor-pointer transition-all ${
                  isDragging
                    ? "border-amber-400 bg-amber-500/10 scale-[0.99]"
                    : "border-slate-700/80 hover:border-slate-600 bg-slate-950/40 hover:bg-slate-950/60"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.docx,.doc,.txt,.md,.rtf,.java,.json,.png,.jpg,.jpeg"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      handleFile(e.target.files[0]);
                    }
                  }}
                />
                <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                  <UploadCloud className="w-7 h-7" />
                </div>
                <h3 className="text-base font-semibold text-white mb-1">
                  Drag and drop your document or PDF here
                </h3>
                <p className="text-xs text-slate-400 mb-3 max-w-md mx-auto">
                  Supports <strong className="text-slate-300">PDF</strong>,{" "}
                  <strong className="text-slate-300">Word (.docx, .doc)</strong>,{" "}
                  <strong className="text-slate-300">Markdown (.md)</strong>,{" "}
                  <strong className="text-slate-300">Text</strong>, or screenshots of problem specifications.
                </p>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors">
                  <span>Browse local files</span>
                </div>
              </div>
            ) : (
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                    <FileCheck className="w-5 h-5" />
                  </div>
                  <div className="truncate">
                    <p className="text-sm font-semibold text-white truncate">
                      {selectedFile.file.name}
                    </p>
                    <p className="text-xs text-slate-400">
                      {formatFileSize(selectedFile.file.size)} • Ready for Java synthesis
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedFile(null)}
                  className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                  title="Remove file"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* Text specification tab */}
        {activeTab === "text" && (
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              Paste assignment problem statement, class diagrams, or API specifications:
            </label>
            <textarea
              rows={7}
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              placeholder="Paste requirements here... e.g.:&#10;- Create a thread-safe order processor with discount strategies&#10;- Must include Customer, Order, OrderItem classes&#10;- Calculate 10% discount for orders over $100&#10;- Write JUnit 5 test suite verifying edge cases..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 focus:ring-1 focus:ring-amber-400 rounded-xl p-3.5 text-xs text-slate-200 font-mono resize-y placeholder:text-slate-600 outline-none transition-colors"
            />
          </div>
        )}

        {/* Configuration settings toggle */}
        <div className="border border-slate-800/80 bg-slate-950/50 rounded-xl overflow-hidden">
          <button
            type="button"
            onClick={() => setShowConfig(!showConfig)}
            className="w-full px-4 py-3 flex items-center justify-between text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800/40 transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>
                Java Compiler & Architecture Settings (Java {options.javaVersion},{" "}
                {options.projectType === "standard"
                  ? "Standard OOP"
                  : options.projectType === "spring-boot"
                  ? "Spring Boot 3"
                  : options.projectType === "junit"
                  ? "Test-Driven"
                  : "Data Structures"}
                , {options.buildTool})
              </span>
            </div>
            {showConfig ? (
              <ChevronUp className="w-4 h-4 text-slate-400" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-400" />
            )}
          </button>

          {showConfig && (
            <div className="p-4 pt-2 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              {/* Java Version */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1.5">
                  Target Java Version
                </label>
                <select
                  value={options.javaVersion}
                  onChange={(e) =>
                    setOptions({
                      ...options,
                      javaVersion: e.target.value as any,
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white outline-none focus:border-amber-400"
                >
                  <option value="21">Java 21 (Modern LTS - Records, Pattern Matching)</option>
                  <option value="17">Java 17 (Enterprise LTS)</option>
                  <option value="11">Java 11 (Legacy LTS)</option>
                  <option value="8">Java 8 (Backwards Compatible)</option>
                </select>
              </div>

              {/* Architecture Style */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1.5">
                  Architecture Style
                </label>
                <select
                  value={options.projectType}
                  onChange={(e) =>
                    setOptions({
                      ...options,
                      projectType: e.target.value as any,
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white outline-none focus:border-amber-400"
                >
                  <option value="standard">Standard Clean OOP (CLI / Domain Logic)</option>
                  <option value="spring-boot">Spring Boot 3 (Controller, Service, Repository)</option>
                  <option value="data-structures">Data Structures & High-Performance Algorithms</option>
                  <option value="junit">Test-Driven Development (Exhaustive JUnit 5)</option>
                </select>
              </div>

              {/* Build Tool */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1.5">
                  Build System
                </label>
                <select
                  value={options.buildTool}
                  onChange={(e) =>
                    setOptions({
                      ...options,
                      buildTool: e.target.value as any,
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white outline-none focus:border-amber-400"
                >
                  <option value="single-file">Single Self-Contained .java File (Human-Written, 0 Dependencies)</option>
                  <option value="maven">Maven Project (pom.xml with standard folder structure)</option>
                  <option value="gradle">Gradle Project (build.gradle)</option>
                </select>
              </div>

              {/* Package name */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1.5">
                  Target Java Package
                </label>
                <input
                  type="text"
                  value={options.targetPackage}
                  onChange={(e) =>
                    setOptions({ ...options, targetPackage: e.target.value })
                  }
                  placeholder="com.example.solution"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono outline-none focus:border-amber-400"
                />
              </div>

              {/* Optimization Goal */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1.5">
                  Engineering Goal
                </label>
                <select
                  value={options.optimizationGoal}
                  onChange={(e) =>
                    setOptions({
                      ...options,
                      optimizationGoal: e.target.value as any,
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white outline-none focus:border-amber-400"
                >
                  <option value="clean-code">Clean Code & SOLID Principles</option>
                  <option value="high-performance">High Throughput & Memory Efficiency</option>
                  <option value="educational-step-by-step">Educational / Step-by-Step with Javadoc</option>
                  <option value="enterprise-robust">Enterprise Robust & Defensive</option>
                </select>
              </div>

              {/* Additional instructions */}
              <div className="sm:col-span-2 lg:col-span-3">
                <label className="block text-[11px] font-semibold text-slate-400 mb-1.5">
                  Custom Constraints / Instructions (Optional)
                </label>
                <input
                  type="text"
                  value={options.additionalInstructions}
                  onChange={(e) =>
                    setOptions({
                      ...options,
                      additionalInstructions: e.target.value,
                    })
                  }
                  placeholder="e.g. Ensure no external libraries except JUnit 5; use synchronized blocks; provide Big-O analysis..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white outline-none focus:border-amber-400"
                />
              </div>
            </div>
          )}
        </div>

        {/* Submit button */}
        <div className="flex items-center justify-between pt-2">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>100% human-crafted in one .java file • Zero placeholders • Self-testing harness</span>
          </div>

          <button
            type="submit"
            disabled={!isFormValid || isLoading}
            className={`flex items-center gap-2.5 px-6 py-3 rounded-xl text-sm font-bold transition-all shadow-lg cursor-pointer ${
              !isFormValid || isLoading
                ? "bg-slate-800 text-slate-500 cursor-not-allowed"
                : "bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/25 hover:shadow-amber-500/40 hover:scale-[1.02] active:scale-[0.98]"
            }`}
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>Crafting Best Java Code...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-slate-950 fill-current" />
                <span>Generate Best Java Code</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
