import React, { useState } from "react";
import {
  Wand2,
  Send,
  Sparkles,
  Zap,
  CheckCircle,
  FileCode,
  ArrowRight,
} from "lucide-react";
import { JavaProjectResponse } from "../types";

interface RefinementPanelProps {
  project: JavaProjectResponse;
  onRefine: (instruction: string, targetFile?: string) => void;
  isRefining: boolean;
}

export const RefinementPanel: React.FC<RefinementPanelProps> = ({
  project,
  onRefine,
  isRefining,
}) => {
  const [instruction, setInstruction] = useState("");
  const [targetFile, setTargetFile] = useState<string>("ALL");

  const quickPrompts = [
    "Make it thread-safe using ConcurrentHashMap or ReentrantLock",
    "Add more edge-case unit tests in JUnit 5",
    "Optimize for O(1) time complexity and memory usage",
    "Add Javadoc comments with parameter and return explanations",
    "Convert POJOs to modern Java 21 Records",
    "Add defensive validation for null/empty inputs",
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!instruction.trim() || isRefining) return;
    onRefine(instruction.trim(), targetFile === "ALL" ? undefined : targetFile);
    setInstruction("");
  };

  const handleSelectQuickPrompt = (promptText: string) => {
    setInstruction(promptText);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-2xl">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <Wand2 className="w-3.5 h-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Interactive Refine & Enhance Code
            </h3>
            <p className="text-[11px] text-slate-400">
              Request changes, algorithmic tweaks, additional test cases, or framework adaptations
            </p>
          </div>
        </div>
      </div>

      {/* Quick suggestions pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-3 scrollbar-none">
        {quickPrompts.map((prompt, i) => (
          <button
            key={i}
            type="button"
            onClick={() => handleSelectQuickPrompt(prompt)}
            className="text-[11px] px-2.5 py-1 rounded-full bg-slate-950 border border-slate-800 text-slate-300 hover:text-amber-300 hover:border-amber-500/40 transition-colors whitespace-nowrap cursor-pointer shrink-0"
          >
            + {prompt}
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="flex flex-col sm:flex-row gap-2">
          <select
            value={targetFile}
            onChange={(e) => setTargetFile(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none focus:border-amber-400 sm:w-48 shrink-0"
          >
            <option value="ALL">All Project Files</option>
            {project.files.map((file, idx) => (
              <option key={idx} value={file.fileName}>
                Focus: {file.fileName}
              </option>
            ))}
          </select>

          <div className="relative flex-1">
            <input
              type="text"
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
              placeholder="e.g. Add validation for negative prices, add support for UUIDs, or switch to builder pattern..."
              disabled={isRefining}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-3.5 pr-10 py-2 text-xs text-white placeholder:text-slate-500 outline-none focus:border-amber-400 transition-colors"
            />
            <button
              type="submit"
              disabled={!instruction.trim() || isRefining}
              className={`absolute right-1.5 top-1.5 bottom-1.5 px-3 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
                !instruction.trim() || isRefining
                  ? "text-slate-600 bg-transparent"
                  : "bg-amber-500 text-slate-950 hover:bg-amber-400 font-bold shadow-md shadow-amber-500/20"
              }`}
            >
              {isRefining ? (
                <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
