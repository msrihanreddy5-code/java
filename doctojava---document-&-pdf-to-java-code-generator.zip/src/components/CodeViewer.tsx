import React, { useState, useMemo } from "react";
import Prism from "prismjs";
import "prismjs/components/prism-java";
import "prismjs/components/prism-markup";
import "prismjs/components/prism-groovy";
import {
  Copy,
  Check,
  Download,
  FolderArchive,
  FileCode,
  ShieldCheck,
  Search,
  CheckCircle,
  CheckCircle2,
  FileText,
  Terminal,
  Maximize2,
  Minimize2,
  Sparkles,
  Zap,
  Layers,
  Code,
  Clock,
  HardDrive,
  PlayCircle,
} from "lucide-react";
import { GeneratedFile, JavaProjectResponse } from "../types";
import { downloadSingleFile, downloadProjectAsZip } from "../utils/zipExport";

interface CodeViewerProps {
  project: JavaProjectResponse;
  onVerify: () => void;
  isVerifying: boolean;
}

export const CodeViewer: React.FC<CodeViewerProps> = ({
  project,
  onVerify,
  isVerifying,
}) => {
  // Default to single self-contained file as requested
  const [viewMode, setViewMode] = useState<"single" | "modular">("single");
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  const singleFile = project.singleFileJava || {
    fileName: "Main.java",
    className: "Main",
    fullCode: project.files[0]?.content || "",
    executionCommand: "java Main.java",
    timeComplexity: "O(N)",
    spaceComplexity: "O(1)",
    builtInTestCount: 5,
  };

  const currentFile: GeneratedFile = useMemo(() => {
    if (viewMode === "single") {
      return {
        fileName: singleFile.fileName,
        filePath: singleFile.fileName,
        description: `100% Complete self-contained Java compilation unit with built-in test suite in main()`,
        isMain: true,
        isTest: false,
        content: singleFile.fullCode,
      };
    }
    return project.files[selectedFileIndex] || project.files[0];
  }, [viewMode, singleFile, project.files, selectedFileIndex]);

  // Syntax highlighting
  const highlightedCode = useMemo(() => {
    if (!currentFile?.content) return "";
    let lang = Prism.languages.java;
    let grammar = "java";

    if (currentFile.fileName.endsWith(".xml") || currentFile.fileName === "pom.xml") {
      lang = Prism.languages.markup || Prism.languages.html;
      grammar = "markup";
    } else if (currentFile.fileName.endsWith(".gradle")) {
      lang = Prism.languages.groovy || Prism.languages.java;
      grammar = "groovy";
    }

    try {
      return Prism.highlight(currentFile.content, lang, grammar);
    } catch {
      return currentFile.content;
    }
  }, [currentFile]);

  const lines = useMemo(() => {
    return currentFile?.content ? currentFile.content.split("\n") : [];
  }, [currentFile]);

  const handleCopy = () => {
    if (!currentFile) return;
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyCommand = () => {
    navigator.clipboard.writeText(singleFile.executionCommand);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  const handleDownload = () => {
    downloadSingleFile(currentFile);
  };

  const handleDownloadZip = async () => {
    setIsDownloadingZip(true);
    try {
      await downloadProjectAsZip(project);
    } finally {
      setIsDownloadingZip(false);
    }
  };

  return (
    <div
      className={`bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col shadow-2xl transition-all ${
        isFullscreen ? "fixed inset-3 z-50 rounded-xl" : "h-[780px]"
      }`}
    >
      {/* Top Header / Project Info Bar */}
      <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-slate-950 font-mono text-sm font-black shadow-md shadow-amber-500/20">
            {"☕"}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white tracking-wide">
                {project.projectName}
              </h2>
              <span className="px-2 py-0.5 text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                <span>Zero Limits • Full Implementation</span>
              </span>
            </div>
            <p className="text-[11px] text-slate-400 line-clamp-1 max-w-xl">
              {project.summary}
            </p>
          </div>
        </div>

        {/* Global Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={onVerify}
            disabled={isVerifying}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 border border-emerald-800/60 transition-all cursor-pointer shadow-sm"
            title="Run comprehensive Java compiler static verification"
          >
            {isVerifying ? (
              <div className="w-3.5 h-3.5 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
            ) : (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            )}
            <span>Audit & Verify</span>
          </button>

          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all cursor-pointer shadow-sm"
            title={`Download ${currentFile.fileName}`}
          >
            <Download className="w-3.5 h-3.5 text-amber-400" />
            <span>Download {currentFile.fileName}</span>
          </button>

          <button
            onClick={handleDownloadZip}
            disabled={isDownloadingZip}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 transition-all cursor-pointer shadow-md shadow-amber-500/20 active:scale-95"
            title="Download complete Maven project ZIP"
          >
            <FolderArchive className="w-3.5 h-3.5" />
            <span>Project ZIP</span>
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
          >
            {isFullscreen ? (
              <Minimize2 className="w-4 h-4" />
            ) : (
              <Maximize2 className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>

      {/* Mode Switcher Bar */}
      <div className="bg-slate-950/90 px-4 py-2 border-b border-slate-800/90 flex flex-wrap items-center justify-between gap-3">
        {/* Toggle between Single Human-Written File vs Modular Package */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl">
          <button
            onClick={() => setViewMode("single")}
            className={`flex items-center gap-2 px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              viewMode === "single"
                ? "bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Single Self-Contained .java File (Human-Written)</span>
          </button>

          <button
            onClick={() => setViewMode("modular")}
            className={`flex items-center gap-2 px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              viewMode === "modular"
                ? "bg-slate-800 text-white border border-slate-700 shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-blue-400" />
            <span>Modular Project Files ({project.files.length})</span>
          </button>
        </div>

        {/* Big-O Badges & Test Count (for Single File) */}
        {viewMode === "single" && (
          <div className="flex items-center gap-2 flex-wrap text-xs">
            {singleFile.timeComplexity && (
              <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-slate-300 font-mono text-[11px]">
                <Clock className="w-3 h-3 text-amber-400" />
                <span>Time: {singleFile.timeComplexity}</span>
              </span>
            )}
            {singleFile.spaceComplexity && (
              <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-slate-300 font-mono text-[11px]">
                <HardDrive className="w-3 h-3 text-blue-400" />
                <span>Space: {singleFile.spaceComplexity}</span>
              </span>
            )}
            <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-medium text-[11px]">
              <PlayCircle className="w-3 h-3" />
              <span>Self-Testing Harness Included</span>
            </span>
          </div>
        )}
      </div>

      {/* Questions Solved Banner */}
      {project.questionsSolved && project.questionsSolved.length > 0 && (
        <div className="bg-emerald-950/30 border-b border-emerald-900/40 px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="flex items-center gap-1 font-bold text-emerald-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>All Questions Solved ({project.questionsSolved.length}):</span>
            </span>
            <div className="flex items-center gap-1.5 flex-wrap">
              {project.questionsSolved.map((q, i) => (
                <span
                  key={i}
                  className="px-2.5 py-0.5 rounded-full bg-slate-950 text-slate-200 border border-emerald-800/50 font-medium text-[11px] shadow-xs"
                >
                  ✓ {q}
                </span>
              ))}
            </div>
          </div>
          <span className="text-[11px] text-emerald-400 font-mono font-semibold">
            100% Complete Implementation in Main.java
          </span>
        </div>
      )}

      {/* Modular File Navigation Tabs (shown if modular view selected) */}
      {viewMode === "modular" && (
        <div className="bg-slate-950/60 px-3 pt-2 border-b border-slate-800 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {project.files.map((file, idx) => {
            const isActive = idx === selectedFileIndex;
            const isTest = file.isTest || file.fileName.includes("Test");
            const isConfig =
              file.fileName.endsWith(".xml") || file.fileName.endsWith(".gradle");

            return (
              <button
                key={idx}
                onClick={() => setSelectedFileIndex(idx)}
                className={`flex items-center gap-2 px-3 py-2 rounded-t-lg text-xs font-mono transition-all border-t-2 shrink-0 cursor-pointer ${
                  isActive
                    ? "bg-slate-900 text-amber-300 border-amber-500 shadow-sm"
                    : "bg-slate-950/40 text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-900/40"
                }`}
              >
                <FileCode
                  className={`w-3.5 h-3.5 ${
                    isTest
                      ? "text-emerald-400"
                      : isConfig
                      ? "text-blue-400"
                      : "text-amber-400"
                  }`}
                />
                <span className="font-medium">{file.fileName}</span>
                {isTest && (
                  <span className="text-[9px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300 uppercase font-sans">
                    test
                  </span>
                )}
                {file.isMain && (
                  <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 uppercase font-sans">
                    main
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Breadcrumb & One-Click Run Bar */}
      <div className="bg-slate-900 px-4 py-2 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 text-slate-400 font-mono">
          <span className="text-slate-500">File:</span>
          <span className="text-amber-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800 font-bold">
            {currentFile.fileName}
          </span>
          <span className="text-slate-500">•</span>
          <span className="text-slate-400">{lines.length} lines</span>

          {viewMode === "single" && (
            <>
              <span className="text-slate-600 hidden sm:inline">|</span>
              <span className="text-slate-400 hidden sm:inline">Quick Run:</span>
              <button
                onClick={handleCopyCommand}
                className="hidden sm:inline-flex items-center gap-1.5 bg-slate-950 hover:bg-slate-800 px-2.5 py-0.5 rounded border border-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
                title="Click to copy run command"
              >
                <code>{singleFile.executionCommand}</code>
                {copiedCmd ? (
                  <Check className="w-3 h-3 text-emerald-400" />
                ) : (
                  <Copy className="w-3 h-3 text-slate-500" />
                )}
              </button>
            </>
          )}
        </div>

        {/* Code Actions */}
        <div className="flex items-center gap-2">
          {/* Quick search inside file */}
          <div className="relative flex items-center">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2 pointer-events-none" />
            <input
              type="text"
              placeholder="Find in code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-md pl-7 pr-2 py-1 text-[11px] text-slate-200 outline-none focus:border-amber-400 w-32 focus:w-44 transition-all"
            />
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-all cursor-pointer shadow-md shadow-amber-500/20 active:scale-95"
            title="Copy entire Java file"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-slate-950 stroke-[3]" />
                <span>Copied Full File!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Copy Full .java Code</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Code Editor / Highlighting Area */}
      <div className="flex-1 overflow-auto bg-[#0d1117] relative flex">
        {/* Line numbers gutter */}
        <div className="select-none py-4 px-3 text-right font-mono text-xs text-slate-600 bg-[#0d1117] border-r border-slate-800/60 sticky left-0 shrink-0">
          {lines.map((_, i) => (
            <div key={i} className="leading-6">
              {i + 1}
            </div>
          ))}
        </div>

        {/* Code Content */}
        <div className="p-4 flex-1 overflow-x-auto">
          <pre className="font-mono text-xs leading-6 tab-size-4 text-slate-200 whitespace-pre">
            <code
              dangerouslySetInnerHTML={{
                __html: highlightedCode,
              }}
            />
          </pre>
        </div>
      </div>

      {/* Bottom status bar */}
      <div className="bg-slate-950 px-4 py-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-2">
          <span className="text-amber-400 font-semibold">Architectural Standard:</span>
          <span className="text-slate-300">
            {viewMode === "single"
              ? "Human-written, self-contained single .java compilation unit"
              : currentFile.description}
          </span>
        </div>
        <div className="flex items-center gap-3 font-mono">
          <span>UTF-8</span>
          <span>Java 21</span>
          <span>LF</span>
        </div>
      </div>
    </div>
  );
};
