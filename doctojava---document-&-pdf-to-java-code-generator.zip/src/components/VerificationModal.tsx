import React from "react";
import {
  X,
  ShieldCheck,
  AlertTriangle,
  Info,
  CheckCircle2,
  FileCode,
  Award,
  Sparkles,
} from "lucide-react";
import { VerificationResult } from "../types";

interface VerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: VerificationResult | null;
  isLoading: boolean;
}

export const VerificationModal: React.FC<VerificationModalProps> = ({
  isOpen,
  onClose,
  result,
  isLoading,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                Java Compiler & Static Analysis Audit
              </h3>
              <p className="text-xs text-slate-400">
                Rigorous inspection of syntax, imports, types, and modern idioms
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {isLoading ? (
            <div className="py-12 text-center space-y-4">
              <div className="w-10 h-10 border-3 border-emerald-400 border-t-transparent rounded-full animate-spin mx-auto" />
              <div>
                <p className="text-sm font-semibold text-white">
                  Executing Static Analysis...
                </p>
                <p className="text-xs text-slate-400">
                  Checking abstract syntax trees, generic type safety, and package bindings
                </p>
              </div>
            </div>
          ) : result ? (
            <>
              {/* Score card */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-mono font-bold text-lg">
                    {result.score <= 10 ? result.score * 10 : result.score}%
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400 block">Quality Score</span>
                    <span className="text-xs font-bold text-emerald-400 uppercase">
                      {result.status.replace("_", " ")}
                    </span>
                  </div>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 col-span-2 flex items-center">
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {result.executionSummary}
                  </p>
                </div>
              </div>

              {/* Diagnostics */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Diagnostics & Compiler Rules
                </h4>
                <div className="space-y-2">
                  {result.diagnostics.map((diag, i) => (
                    <div
                      key={i}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-2.5 text-xs"
                    >
                      {diag.severity === "ERROR" ? (
                        <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                      ) : diag.severity === "WARNING" ? (
                        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[11px] font-semibold text-slate-200">
                            {diag.file}
                          </span>
                          <span
                            className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                              diag.severity === "ERROR"
                                ? "bg-red-500/20 text-red-300"
                                : diag.severity === "WARNING"
                                ? "bg-amber-500/20 text-amber-300"
                                : "bg-emerald-500/20 text-emerald-300"
                            }`}
                          >
                            {diag.severity}
                          </span>
                        </div>
                        <p className="text-slate-300 mt-1">{diag.message}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Best Practices */}
              {result.bestPractices && result.bestPractices.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-amber-400" />
                    <span>Best Practices Verified</span>
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {result.bestPractices.map((bp, i) => (
                      <div
                        key={i}
                        className="p-2.5 bg-slate-950 rounded-lg border border-slate-800/80 text-slate-300 flex items-center gap-2"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>{bp}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <p className="text-xs text-slate-400 text-center py-8">
              No verification results yet. Click Verify in the editor toolbar.
            </p>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-950 px-6 py-3 border-t border-slate-800 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors cursor-pointer"
          >
            Close Audit
          </button>
        </div>
      </div>
    </div>
  );
};
