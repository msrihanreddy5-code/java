import React, { useState } from "react";
import {
  Terminal,
  Play,
  Cpu,
  Layers,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Copy,
  Check,
} from "lucide-react";
import { JavaProjectResponse } from "../types";

interface TerminalOutputProps {
  project: JavaProjectResponse;
}

export const TerminalOutput: React.FC<TerminalOutputProps> = ({ project }) => {
  const [activeTab, setActiveTab] = useState<
    "terminal" | "architecture" | "edge-cases" | "compilation"
  >("terminal");
  const [copied, setCopied] = useState(false);

  const handleCopyOutput = () => {
    navigator.clipboard.writeText(project.sampleRunOutput);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col">
      {/* Tab Header */}
      <div className="bg-slate-950 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setActiveTab("terminal")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === "terminal"
                ? "bg-slate-800 text-amber-300 border border-slate-700"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-amber-400" />
            <span>Execution Terminal Output</span>
          </button>

          <button
            onClick={() => setActiveTab("architecture")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === "architecture"
                ? "bg-slate-800 text-amber-300 border border-slate-700"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-blue-400" />
            <span>Architecture & Design</span>
          </button>

          <button
            onClick={() => setActiveTab("edge-cases")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === "edge-cases"
                ? "bg-slate-800 text-amber-300 border border-slate-700"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Edge Cases & Defenses</span>
            <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] flex items-center justify-center font-bold">
              {project.edgeCasesHandled.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab("compilation")}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === "compilation"
                ? "bg-slate-800 text-amber-300 border border-slate-700"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Cpu className="w-3.5 h-3.5 text-purple-400" />
            <span>Compiler Entrypoint</span>
          </button>
        </div>

        {activeTab === "terminal" && (
          <button
            onClick={handleCopyOutput}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" />
                <span>Copy stdout</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* Tab Contents */}
      <div className="p-4 bg-slate-950/60 min-h-[220px] max-h-[360px] overflow-auto">
        {/* Terminal output */}
        {activeTab === "terminal" && (
          <div className="font-mono text-xs leading-5">
            <div className="flex items-center gap-2 text-slate-500 mb-2 pb-2 border-b border-slate-800/80 text-[11px]">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500/80 inline-block" />
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80 inline-block" />
              <span className="w-2.5 h-2.5 rounded-full bg-green-500/80 inline-block" />
              <span className="ml-2 font-semibold text-slate-400">
                Run Simulation: {project.compilationCheck.entryPoint || "mvn test"}
              </span>
            </div>
            <pre className="text-emerald-300 whitespace-pre-wrap font-mono">
              {project.sampleRunOutput ||
                `[INFO] -------------------------------------------------------\n[INFO] BUILD SUCCESS\n[INFO] Tests run: 8, Failures: 0, Errors: 0, Skipped: 0\n[INFO] -------------------------------------------------------`}
            </pre>
          </div>
        )}

        {/* Architecture overview */}
        {activeTab === "architecture" && (
          <div className="space-y-4 text-xs">
            <div>
              <h4 className="text-sm font-semibold text-white mb-1.5 flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                <span>Design Patterns & Architectural Approach</span>
              </h4>
              <p className="text-slate-300 leading-relaxed bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                {project.architectureOverview}
              </p>
            </div>

            <div>
              <h5 className="font-semibold text-slate-300 mb-2">Key Classes & Responsibilities</h5>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {project.keyClasses.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 bg-slate-900/40 border border-slate-800/80 rounded-lg flex items-start gap-2"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 mt-0.5 shrink-0" />
                    <span className="text-slate-200 font-mono text-[11px]">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Edge Cases & Defenses */}
        {activeTab === "edge-cases" && (
          <div className="space-y-4 text-xs">
            <div>
              <h4 className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Defensive Programming & Edge Cases Handled</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {project.edgeCasesHandled.map((edgeCase, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-emerald-950/20 border border-emerald-900/40 rounded-xl flex items-start gap-2.5"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span className="text-slate-200">{edgeCase}</span>
                  </div>
                ))}
              </div>
            </div>

            {project.assumptionsMade && project.assumptionsMade.length > 0 && (
              <div>
                <h5 className="font-semibold text-slate-400 mb-1.5 flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Specification Assumptions Made</span>
                </h5>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {project.assumptionsMade.map((asm, idx) => (
                    <li key={idx} className="text-slate-400">
                      {asm}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        {/* Compiler Entrypoint & Notes */}
        {activeTab === "compilation" && (
          <div className="space-y-3 text-xs">
            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
              <span className="text-slate-400 block mb-1 font-semibold">How to Compile & Run:</span>
              <code className="text-amber-300 font-mono text-xs block bg-slate-950 p-2 rounded border border-slate-800">
                {project.compilationCheck.entryPoint}
              </code>
            </div>

            <div>
              <span className="text-slate-400 block mb-1 font-semibold">Verification Notes:</span>
              <ul className="space-y-1.5">
                {project.compilationCheck.notes.map((note, idx) => (
                  <li
                    key={idx}
                    className="flex items-center gap-2 text-slate-300 bg-slate-900/40 px-3 py-1.5 rounded-lg border border-slate-800/60"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
