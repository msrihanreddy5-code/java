export interface GeneratedFile {
  fileName: string;
  filePath: string;
  description: string;
  isMain: boolean;
  isTest: boolean;
  content: string;
}

export interface CompilationCheck {
  status: "PASS" | "WARNING";
  notes: string[];
  entryPoint: string;
}

export interface SingleFileJava {
  fileName: string;
  className: string;
  fullCode: string;
  executionCommand: string;
  timeComplexity: string;
  spaceComplexity: string;
  builtInTestCount: number;
}

export interface JavaProjectResponse {
  projectName: string;
  summary: string;
  questionsSolved: string[];
  architectureOverview: string;
  keyClasses: string[];
  singleFileJava: SingleFileJava;
  files: GeneratedFile[];
  compilationCheck: CompilationCheck;
  sampleRunOutput: string;
  assumptionsMade: string[];
  edgeCasesHandled: string[];
}

export interface ProjectOptions {
  javaVersion: "21" | "17" | "11" | "8";
  projectType: "standard" | "spring-boot" | "junit" | "data-structures";
  buildTool: "maven" | "gradle" | "single-file";
  targetPackage: string;
  optimizationGoal: "clean-code" | "high-performance" | "educational-step-by-step" | "enterprise-robust";
  additionalInstructions: string;
}

export interface DiagnosticItem {
  file: string;
  severity: "INFO" | "WARNING" | "ERROR";
  message: string;
}

export interface VerificationResult {
  status: "VERIFIED_COMPILABLE" | "NEEDS_ATTENTION";
  score: number;
  diagnostics: DiagnosticItem[];
  bestPractices: string[];
  executionSummary: string;
}

export interface HistoryItem {
  id: string;
  timestamp: number;
  fileName: string;
  sourceType: "pdf" | "docx" | "text" | "sample";
  projectData: JavaProjectResponse;
}
